#include "coffee.h"

using namespace std;


//function defintions from coffee.h goes here